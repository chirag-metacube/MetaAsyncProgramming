﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Async.Controllers
{
    public class TaskTestController : Controller
    {
        // GET: TaskTest
        public ActionResult Index()
        {
            return View();
        }
    }
}