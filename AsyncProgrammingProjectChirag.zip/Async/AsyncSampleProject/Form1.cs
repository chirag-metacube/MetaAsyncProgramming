﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncSampleProject
{
    public partial class Form1 : Form
    {
        private int _grandTotal;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread.CurrentThread.Name = "Main";

            // Create a task and supply a user delegate by using a lambda expression. 
            Task taskA = new Task(() => Console.WriteLine("Hello from taskA."));
            // Start the task.
            taskA.Start();

            // Output a message from the calling thread.
            Console.WriteLine("Hello from thread '{0}'.",
                              Thread.CurrentThread.Name);
            taskA.Wait();
        }

        private void WithAsync_Click(object sender, EventArgs e)
        {
            _grandTotal = 0;
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Parallel.For(0, 100000000, x => Sum(_grandTotal));
            stopwatch.Stop();
            MessageBox.Show(String.Format("Sum total of all the numbers in the array is {0}. It took {1} miliseconds to perform this sum.", _grandTotal, stopwatch.ElapsedMilliseconds));
            //resetting sumTotal for next button click
            _grandTotal = 0;
        }

        private void WithoutAsync_Click(object sender, EventArgs e)
        {
            _grandTotal = 0;
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            for (var i = 0; i < 100000000; i++)
            {
                _grandTotal = Sum(_grandTotal);
            }
            stopwatch.Stop();
            MessageBox.Show(String.Format("Sum total of all the numbers in the array is {0}. It took {1} miliseconds to perform this sum.", _grandTotal, stopwatch.ElapsedMilliseconds));
            //resetting sumTotal for next button click
        }

        private int Sum(int value)
        {
            return value++;
        }
    }
}
